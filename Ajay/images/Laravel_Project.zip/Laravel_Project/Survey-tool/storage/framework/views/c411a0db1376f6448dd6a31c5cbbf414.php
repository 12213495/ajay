<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto py-6 sm:px-6 lg:px-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-lg">
        <div class="px-4 py-5 sm:px-6">
            <h1 class="text-2xl font-bold text-gray-900"><?php echo e($survey->title); ?></h1>
            <?php if($survey->description): ?>
                <p class="mt-1 text-sm text-gray-500"><?php echo e($survey->description); ?></p>
            <?php endif; ?>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('responses.store', $survey)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            
            <div class="border-t border-gray-200 px-4 py-5 sm:px-6">
                <?php $__currentLoopData = $survey->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700">
                            <?php echo e($question->question_text); ?>

                            <?php if($question->is_required): ?>
                                <span class="text-red-500">*</span>
                            <?php endif; ?>
                        </label>

                        <?php switch($question->type->name):
                            case ('Text'): ?>
                                <input type="text" 
                                       name="responses[<?php echo e($question->id); ?>][answer]" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                       <?php if($question->is_required): ?> required <?php endif; ?>>
                                <?php break; ?>

                            <?php case ('Textarea'): ?>
                                <textarea name="responses[<?php echo e($question->id); ?>][answer]" 
                                          rows="3"
                                          class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                          <?php if($question->is_required): ?> required <?php endif; ?>></textarea>
                                <?php break; ?>

                            <?php case ('Multiple Choice'): ?>
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mt-2">
                                        <label class="inline-flex items-center">
                                            <input type="radio" 
                                                   name="responses[<?php echo e($question->id); ?>][answer]" 
                                                   value="<?php echo e($option->id); ?>"
                                                   class="form-radio h-4 w-4 text-indigo-600"
                                                   <?php if($question->is_required): ?> required <?php endif; ?>>
                                            <span class="ml-2"><?php echo e($option->option_text); ?></span>
                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php break; ?>

                            <?php case ('Checkbox'): ?>
                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mt-2">
                                        <label class="inline-flex items-center">
                                            <input type="checkbox" 
                                                   name="responses[<?php echo e($question->id); ?>][answer][]" 
                                                   value="<?php echo e($option->id); ?>"
                                                   class="form-checkbox h-4 w-4 text-indigo-600">
                                            <span class="ml-2"><?php echo e($option->option_text); ?></span>
                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php break; ?>
                        <?php endswitch; ?>

                        <input type="hidden" name="responses[<?php echo e($question->id); ?>][question_id]" value="<?php echo e($question->id); ?>">

                        <?php $__errorArgs = ["responses.{$question->id}.answer"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="mt-6">
                    <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Submit Survey
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel_Project\Survey-tool\resources\views/survey/public/show.blade.php ENDPATH**/ ?>